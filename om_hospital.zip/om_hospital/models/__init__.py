# -*- coding: utf-8 -*-


from . import patients
from . import appointments
