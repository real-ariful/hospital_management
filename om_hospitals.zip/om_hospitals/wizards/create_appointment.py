# -*- coding: utf-8 -*-

from odoo import models, fields, api


class CreateAppointment(models.TransientModel):
    _name = 'create.appointment'

    patient_id = fields.Char(string="Patient")
    appointment_date = fields.Date(string="Appointment Date")


    def create_appointment_wizard__(self):
        print("--------------------")
        print("--------------------")
        print("--------------------")



class Wizard(models.TransientModel):
    _name = 'openacademy.wizard'
    _description = "Wizard: Quick Registration of Attendees to Sessions"

    #session_id = fields.Many2one('openacademy.session',
    #    string="Session", required=True)
    #attendee_ids = fields.Many2many('res.partner', string="Attendees")
