# -*- coding: utf-8 -*-

from odoo import models, fields, api

class HospitalPatient(models.Model):
    _name = 'hospital.patient'
    _description = 'Patient Record'

    patient_name = fields.Char(string='Name')
    patient_age = fields.Integer('Age')
    value2 = fields.Float(compute="_value_pc", store=True)
    notes = fields.Text(string='Notes')

    # @api.depends('value')
    # def _value_pc(self):
    #     self.value2 = float(self.value) / 100

from odoo import models, fields
class Library2Book2(models.Model):
    _name = 'library2.book2'
    name = fields.Char('Title', required=True)
    date_release = fields.Date('Release Date')
    author_ids = fields.Many2many(
    'res.partner',
    string='Authors'
    )