# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError




class HospitalPatient(models.Model):
    _name = 'hospital.patient'
    _description = 'Patient Record'

    _rec_name = 'name_seq'
    _inherit = ['mail.thread','mail.activity.mixin']

    def create_appointment_wizard__(self):
        print("--------------------")
        print("--------------------")
        print("--------------------")

    def get_appointment_count(self):
        count = len(self.env['hospital.appointment'].search([('patient_id','=',self.id)])._ids)
        self.appointment_count = count

    def open_patient_appointment(self):
        action_vals = {
            'name': ('Appointments'),
            'domain': [('patient_id','=',self.id)],
            'res_model': 'hospital.appointment',
            'view_id': False,
            'view_mode': 'tree,form',
            'type': 'ir.actions.act_window',
        }

        return action_vals

    def create_appointment_wizard(self):
        print("----------------------------------------")
        action_vals = {
            'name': ('Appointments'),
            'domain': [('patient_id','=',self.id)],
            'res_model': 'hospital.appointment',
            'view_id': 'create_appointment_wizard',
            'view_mode': 'tree,form',
            'type': 'ir.actions.act_window',
        }

        return action_vals

    state = fields.Char(string="State")

    patient_name = fields.Char(string='Name', track_visibility='always')
    patient_age = fields.Integer('Age', track_visibility='always')
    contact = fields.Integer('Contact No')
    notes = fields.Text(string='Notes')
    name = fields.Char(string="Name")
    name_seq = fields.Char(string="Order Sequence", required=True, copy=False,readonly=True,
                            index=True, default=lambda self: ('New'))

    appointment_count = fields.Integer(string="Appointment", compute='get_appointment_count')
    @api.constrains("patient_age")
    def check_age(self):
        for rec in self:
            if rec.patient_age <= 5:
                raise ValidationError('Age must be greater than 5.')



    @api.model
    def create(self, vals):
        if vals.get('name_seq', ('New')) == ('New'):
           vals['name_seq'] = self.env['ir.sequence'].next_by_code('hospital.patient.sequence') or _('New')
        result = super(HospitalPatient, self).create(vals)
        return result

    @api.depends('patient_age')
    def set_age_group(self):
        for rec in self:
            if rec.patient_age:
                if rec.patient_age < 18:
                    rec.age_group = 'minor'
                else:
                    rec.age_group = 'major'

    age_group = fields.Selection([
        ('major','Major'),
        ('minor','Minor'),

    ], string="Age Group", compute="set_age_group")









from odoo import models, fields
class Library2Book2(models.Model):
    _name = 'library2.book2'
    name = fields.Char('Title', required=True)
    date_release = fields.Date('Release Date')
    author_ids = fields.Many2many(
    'res.partner',
    string='Authors'
    )