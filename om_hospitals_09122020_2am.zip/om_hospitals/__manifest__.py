# -*- coding: utf-8 -*-
{
    'name': "Hospital Management",

    'summary': """Module for managing the hospitals""",

    'description': """Long description of module's purpose
    """,

    'author': "Real Haque",
    'website': "www.azmarifulhaque.online",
    'category': 'Extra Toos',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','mail', 'sale'],

    # always loaded
    'data': [       
        'security/ir.model.access.csv',
        'views/appointment.xml',
        'wizards/create_appointment.xml',
        'views/views.xml',
        'views/templates.xml',
        'data/sequence.xml', 
        'reports/report.xml', 
        'reports/patient_card.xml',               
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    #----------Added
    'installable': True,
    'application': False,
    'auto_install': False,
}